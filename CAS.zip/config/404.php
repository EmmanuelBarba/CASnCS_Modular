<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NEOCMS</title>
    <link rel="shortcut icon" href="../assets/icons/gallery.png" type="image/png">
    <link rel="stylesheet" href="../assets/styles/styleGallery.css">
    <link rel="stylesheet" href="../assets/styles/boton.css">
    <link rel="stylesheet" href="../assets/styles/error.css">
</head>
<body>
    <div class=contenedor2>
        <div class=bloque2>
            <h2>404 Pagina no encontrada</h2>
            <p>¡Vaya! Algo salió mal.<br /><br />Lo sentimos, la pagina que busca no existe o no se pudo encontrar.</p>
            <a class="b2" href="../index_cas.php">Volver</a>
            
        </div>  
    </div> 
</body>
</html>