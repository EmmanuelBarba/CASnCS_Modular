<?php  
    include 'config.php';

	// if(isset($_POST['Buscar'])) {
	// 			$consulta = $con->prepare('SELECT * FROM clientes  WHERE column LIKE ?');
	// 			$consulta->bindValue(1, "%jairo", PDO::PARAM_STR);
	// 			$consulta->execute();
	// 			echo $name;
		
	// 	}else{
			$consulta = $con->query("SELECT * FROM clientes;");
			$clientes = $consulta->fetchAll(PDO::FETCH_OBJ);
			// header('Location: ../acceso_cas.php');
		// }
	
?>
