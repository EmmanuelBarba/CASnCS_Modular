<?php 

    include 'config.php';
    $consulta = $con->query("SELECT * FROM orden_servicio;");
	$orden = $consulta->fetchAll(PDO::FETCH_OBJ);

?>
